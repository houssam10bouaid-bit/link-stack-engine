"""
Quick test script - run this first to verify everything works
"""

from core.exchange import ExchangeHandler
from core.indicators import ohlcv_to_dataframe, add_basic_indicators, get_latest_signal_row
from config import SYMBOL, TIMEFRAME
from utils.logger import logger

def test():
    logger.info("=== Connection & Data Test ===")
    exchange = ExchangeHandler()

    if not exchange.test_connection():
        logger.error("Connection failed")
        return

    ticker = exchange.get_ticker()
    if ticker:
        logger.info(f"Current {SYMBOL} price: {ticker['last']:.4f}")

    ohlcv = exchange.fetch_ohlcv(timeframe=TIMEFRAME, limit=100)
    if ohlcv:
        df = ohlcv_to_dataframe(ohlcv)
        df = add_basic_indicators(df)
        latest = get_latest_signal_row(df)
        if latest is not None:
            logger.info(f"RSI: {latest['rsi']:.1f} | Trend: {latest['trend']} | EMA50: {latest['ema_fast']:.4f}")
        logger.info("Data fetch OK")
    else:
        logger.error("Failed to fetch OHLCV")

    logger.info("=== Test finished ===")

if __name__ == "__main__":
    test()