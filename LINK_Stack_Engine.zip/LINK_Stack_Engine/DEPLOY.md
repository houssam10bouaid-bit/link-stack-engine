# تعليمات النشر على Railway

## ما تحتاجه منك (مرة واحدة فقط)

### 1. مفاتيح Bybit API
- ادخل حساب Bybit → API Management
- أنشئ مفتاح جديد
- صلاحيات: **Read + Spot Trade فقط** (لا تفعل Withdraw)
- انسخ API Key و Secret

### 2. رفع المشروع على Railway
1. ادخل railway.app
2. New Project → Empty Project
3. Add Service → Empty Service أو GitHub (لاحقاً)
4. ارفع الملفات أو اربط المستودع
5. في Variables أضف:
   BYBIT_API_KEY=xxxxx
   BYBIT_API_SECRET=xxxxx
   MODE=paper
   SYMBOL=LINK/USDT
   TIMEFRAME=1h

6. Deploy

### 3. بعد التأكد
غير MODE=live عندما تكون جاهز للتشغيل الحقيقي.
