"""
LINK Stack Engine - Simple Version v0.3
"""

import time
import schedule
from config import MODE, SYMBOL, TIMEFRAME
from core.exchange import ExchangeHandler
from strategies.simple_accumulation import SimpleAccumulationStrategy
from utils.logger import logger
from utils.kill_switch import is_killed, deactivate_kill
from utils.performance import print_summary

def run_bot():
    logger.info("=" * 55)
    logger.info(f"LINK Stack Engine v0.3 | Mode: {MODE.upper()} | {SYMBOL} | {TIMEFRAME}")
    logger.info("=" * 55)

    deactivate_kill()

    exchange = ExchangeHandler()
    if not exchange.test_connection():
        logger.error("Exchange connection failed. Exiting.")
        return

    strategy = SimpleAccumulationStrategy(exchange)
    print_summary()

    def job():
        if is_killed():
            logger.warning("KILL SWITCH ACTIVE")
            return

        try:
            signal = strategy.analyze(timeframe=TIMEFRAME)
            if signal is None:
                logger.info("No valid market data")
                return

            logger.info(
                f"Price: {signal['price']:.4f} | RSI: {signal['rsi']:.1f} | "
                f"Trend: {signal['trend']} | Action: {signal['action']} | {signal['reason']}"
            )

            if signal["action"] != "hold":
                strategy.execute(signal)
                print_summary()

        except Exception as e:
            logger.error(f"Job error: {e}")

    job()

    if TIMEFRAME == "1h":
        schedule.every(55).minutes.do(job)
    else:
        schedule.every(3).hours.do(job)

    logger.info("Bot running. Create data/KILL to stop.")

    while True:
        if is_killed():
            logger.warning("Kill switch detected. Shutting down.")
            print_summary()
            break
        schedule.run_pending()
        time.sleep(20)

if __name__ == "__main__":
    run_bot()
