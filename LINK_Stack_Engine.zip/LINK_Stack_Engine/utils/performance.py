from utils.state import load_state
from utils.logger import logger

def print_summary():
    state = load_state()
    position = state.get("position_size", 0.0)
    entry = state.get("entry_price")
    total_bought = state.get("total_bought", 0.0)
    total_sold = state.get("total_sold", 0.0)
    net_units = total_bought - total_sold

    logger.info("-" * 40)
    logger.info("PERFORMANCE SUMMARY")
    logger.info(f"Current Position : {position:.6f} LINK")
    logger.info(f"Avg Entry Price  : {entry if entry else 'N/A'}")
    logger.info(f"Total Bought     : {total_bought:.6f} LINK")
    logger.info(f"Total Sold       : {total_sold:.6f} LINK")
    logger.info(f"Net Units Gained : {net_units:.6f} LINK")
    logger.info("-" * 40)