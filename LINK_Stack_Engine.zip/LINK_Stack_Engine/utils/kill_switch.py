import os

KILL_FILE = "data/KILL"

def is_killed():
    return os.path.exists(KILL_FILE)

def activate_kill():
    os.makedirs("data", exist_ok=True)
    with open(KILL_FILE, "w") as f:
        f.write("stopped")
    return True

def deactivate_kill():
    if os.path.exists(KILL_FILE):
        os.remove(KILL_FILE)
    return True