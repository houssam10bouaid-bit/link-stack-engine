import json
import os
from datetime import datetime

STATE_FILE = "data/bot_state.json"

def load_state():
    if not os.path.exists(STATE_FILE):
        return {
            "position_size": 0.0,
            "entry_price": None,
            "last_buy_price": None,
            "total_bought": 0.0,
            "total_sold": 0.0,
            "realized_units_gain": 0.0,
            "last_update": None
        }
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {
            "position_size": 0.0,
            "entry_price": None,
            "last_buy_price": None,
            "total_bought": 0.0,
            "total_sold": 0.0,
            "realized_units_gain": 0.0,
            "last_update": None
        }

def save_state(state):
    os.makedirs("data", exist_ok=True)
    state["last_update"] = datetime.now().isoformat()
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)

def update_position_state(state, action, amount_base, price):
    if action in ["buy", "rebuy"]:
        state["position_size"] = state.get("position_size", 0.0) + amount_base
        state["total_bought"] = state.get("total_bought", 0.0) + amount_base
        if state.get("entry_price") is None:
            state["entry_price"] = price
        else:
            # simple average
            state["entry_price"] = (state["entry_price"] + price) / 2
        state["last_buy_price"] = price

    elif action == "partial_sell":
        sell_amount = state.get("position_size", 0.0) * 0.40
        state["position_size"] = max(0.0, state["position_size"] - sell_amount)
        state["total_sold"] = state.get("total_sold", 0.0) + sell_amount
        return sell_amount

    return amount_base