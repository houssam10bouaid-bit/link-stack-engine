# LINK Stack Engine v0.2 (Simple)

بوت تجميع LINK على Bybit Spot

## الميزات الحالية
- اتصال Bybit Spot
- مؤشرات EMA + RSI
- شراء في الاتجاه الصاعد + RSI منخفض أو قرب EMA
- جني أرباح جزئي
- إعادة تجميع بعد انخفاض
- حفظ الحالة (Position)
- Logging كامل
- Kill Switch (أنشئ ملف data/KILL لإيقاف البوت)

## التشغيل
```bash
pip install -r requirements.txt
cp .env.example .env
# عدّل .env وضع مفاتيح Bybit
python main.py
```

## إيقاف الطوارئ
أنشئ ملف فارغ اسمه KILL داخل مجلد data

## الوضع الافتراضي
MODE=paper (تجريبي)
