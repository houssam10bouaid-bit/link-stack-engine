import os
from dotenv import load_dotenv

load_dotenv()

# ======================
# Exchange Settings
# ======================
BYBIT_API_KEY = os.getenv("BYBIT_API_KEY", "")
BYBIT_API_SECRET = os.getenv("BYBIT_API_SECRET", "")
EXCHANGE_ID = "bybit"

# ======================
# Trading Mode
# ======================
# paper = simulation (no real orders)
# live  = real trading
MODE = os.getenv("MODE", "paper")

# ======================
# Symbol & Timeframe
# ======================
SYMBOL = os.getenv("SYMBOL", "LINK/USDT")
TIMEFRAME = os.getenv("TIMEFRAME", "1h")          # 1h or 4h recommended
QUOTE_CURRENCY = os.getenv("QUOTE_CURRENCY", "USDT")

# ======================
# Risk & Capital
# ======================
# Maximum percentage of available balance to use in one trade (0.0 - 1.0)
MAX_POSITION_PCT = 0.25

# Minimum free USDT to keep as cash buffer
MIN_CASH_BUFFER_USDT = 5.0

# ======================
# Strategy Parameters (Simple Version)
# ======================
# EMA periods
EMA_FAST = 50
EMA_SLOW = 200

# RSI
RSI_PERIOD = 14
RSI_OVERSOLD = 35
RSI_OVERBOUGHT = 70

# Take Profit / Re-Accumulation (percentage)
PARTIAL_TP_PCT = 0.04          # 4% partial take profit
REACCUMULATION_DROP_PCT = 0.025  # look to rebuy after 2.5% drop

# ======================
# Logging
# ======================
LOG_FILE = "logs/bot.log"
ENABLE_CONSOLE_LOG = True