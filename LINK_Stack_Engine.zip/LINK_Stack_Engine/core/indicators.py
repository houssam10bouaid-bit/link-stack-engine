import pandas as pd
import pandas_ta as ta
import numpy as np

def ohlcv_to_dataframe(ohlcv):
    """Convert ccxt OHLCV list to DataFrame"""
    df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df

def add_basic_indicators(df, ema_fast=50, ema_slow=200, rsi_period=14):
    """
    Add the core indicators for the simple version:
    - EMA Fast / Slow
    - RSI
    - Trend direction
    """
    df = df.copy()

    # EMAs
    df["ema_fast"] = ta.ema(df["close"], length=ema_fast)
    df["ema_slow"] = ta.ema(df["close"], length=ema_slow)

    # RSI
    df["rsi"] = ta.rsi(df["close"], length=rsi_period)

    # Simple trend
    df["trend"] = np.where(df["ema_fast"] > df["ema_slow"], "up", "down")

    # Distance from EMA slow (percentage)
    df["dist_ema_slow"] = (df["close"] - df["ema_slow"]) / df["ema_slow"] * 100

    return df

def get_latest_signal_row(df):
    """Return the last fully calculated row"""
    if df is None or len(df) < 5:
        return None
    return df.iloc[-1]