import ccxt
from config import (
    BYBIT_API_KEY,
    BYBIT_API_SECRET,
    EXCHANGE_ID,
    MODE,
    SYMBOL,
    QUOTE_CURRENCY
)
from utils.logger import logger

class ExchangeHandler:
    def __init__(self):
        self.exchange = self._init_exchange()
        self.symbol = SYMBOL
        self.mode = MODE
        # Paper mode simulated balances
        self.paper_usdt = 100.0
        self.paper_link = 0.0

    def _init_exchange(self):
        exchange_class = getattr(ccxt, EXCHANGE_ID)
        exchange = exchange_class({
            "apiKey": BYBIT_API_KEY,
            "secret": BYBIT_API_SECRET,
            "enableRateLimit": True,
            "options": {
                "defaultType": "spot",
            }
        })
        return exchange

    def get_balance(self, currency=None):
        if currency is None:
            currency = QUOTE_CURRENCY

        if self.mode == "paper":
            if currency == "USDT":
                return self.paper_usdt
            if currency == "LINK":
                return self.paper_link
            return 0.0

        try:
            balance = self.exchange.fetch_balance()
            return float(balance.get("free", {}).get(currency, 0.0))
        except Exception as e:
            logger.error(f"Error fetching balance: {e}")
            return 0.0

    def get_ticker(self, symbol=None):
        symbol = symbol or self.symbol
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return {
                "last": float(ticker["last"]),
                "bid": float(ticker["bid"]) if ticker.get("bid") else None,
                "ask": float(ticker["ask"]) if ticker.get("ask") else None,
            }
        except Exception as e:
            logger.error(f"Error fetching ticker: {e}")
            return None

    def fetch_ohlcv(self, timeframe="1h", limit=200):
        try:
            ohlcv = self.exchange.fetch_ohlcv(self.symbol, timeframe=timeframe, limit=limit)
            return ohlcv
        except Exception as e:
            logger.error(f"Error fetching OHLCV: {e}")
            return []

    def create_market_buy(self, amount_quote):
        ticker = self.get_ticker()
        if not ticker:
            return None
        price = ticker["last"]
        amount_base = amount_quote / price

        if self.mode == "paper":
            if self.paper_usdt < amount_quote:
                logger.warning("Paper: insufficient USDT")
                return None
            self.paper_usdt -= amount_quote
            self.paper_link += amount_base
            logger.info(f"[PAPER] BUY {amount_base:.6f} LINK for {amount_quote:.2f} USDT @ {price:.4f}")
            return {"status": "paper_filled", "amount": amount_base, "price": price, "cost": amount_quote}

        try:
            order = self.exchange.create_order(
                symbol=self.symbol,
                type="market",
                side="buy",
                amount=None,
                params={"cost": amount_quote}
            )
            logger.info(f"LIVE BUY order placed: {order.get('id')}")
            return order
        except Exception as e:
            logger.error(f"Market buy failed: {e}")
            return None

    def create_market_sell(self, amount_base):
        ticker = self.get_ticker()
        if not ticker:
            return None
        price = ticker["last"]

        if self.mode == "paper":
            if self.paper_link < amount_base:
                logger.warning("Paper: insufficient LINK")
                return None
            self.paper_link -= amount_base
            self.paper_usdt += amount_base * price
            logger.info(f"[PAPER] SELL {amount_base:.6f} LINK @ {price:.4f}")
            return {"status": "paper_filled", "amount": amount_base, "price": price}

        try:
            order = self.exchange.create_order(
                symbol=self.symbol,
                type="market",
                side="sell",
                amount=amount_base
            )
            logger.info(f"LIVE SELL order placed: {order.get('id')}")
            return order
        except Exception as e:
            logger.error(f"Market sell failed: {e}")
            return None

    def test_connection(self):
        try:
            self.exchange.fetch_time()
            if self.mode == "paper":
                logger.info(f"Paper mode active | Simulated USDT: {self.paper_usdt:.2f}")
            else:
                balance = self.get_balance()
                logger.info(f"Live connection OK | Free USDT: {balance:.2f}")
            return True
        except Exception as e:
            logger.error(f"Connection failed: {e}")
            return False