import pandas as pd
from config import (
    EMA_FAST, EMA_SLOW, RSI_PERIOD,
    RSI_OVERSOLD,
    MAX_POSITION_PCT, MIN_CASH_BUFFER_USDT,
    PARTIAL_TP_PCT, REACCUMULATION_DROP_PCT
)
from core.indicators import ohlcv_to_dataframe, add_basic_indicators, get_latest_signal_row
from utils.state import load_state, save_state, update_position_state
from utils.logger import logger

class SimpleAccumulationStrategy:
    def __init__(self, exchange_handler):
        self.exchange = exchange_handler
        self.state = load_state()

    def analyze(self, timeframe="1h"):
        ohlcv = self.exchange.fetch_ohlcv(timeframe=timeframe, limit=250)
        if not ohlcv or len(ohlcv) < 60:
            return None

        df = ohlcv_to_dataframe(ohlcv)
        df = add_basic_indicators(df, EMA_FAST, EMA_SLOW, RSI_PERIOD)
        latest = get_latest_signal_row(df)

        if latest is None or pd.isna(latest["rsi"]) or pd.isna(latest["ema_fast"]):
            return None

        signal = {
            "price": float(latest["close"]),
            "rsi": float(latest["rsi"]),
            "trend": latest["trend"],
            "ema_fast": float(latest["ema_fast"]),
            "ema_slow": float(latest["ema_slow"]),
            "dist_ema_slow": float(latest["dist_ema_slow"]),
            "action": "hold",
            "reason": ""
        }

        position_size = self.state.get("position_size", 0.0)
        entry_price = self.state.get("entry_price")
        last_buy_price = self.state.get("last_buy_price")

        if position_size <= 0.0001:
            if signal["trend"] == "up" and signal["rsi"] <= RSI_OVERSOLD:
                signal["action"] = "buy"
                signal["reason"] = "Uptrend + RSI oversold"
            elif signal["trend"] == "up" and -2.5 < signal["dist_ema_slow"] < 1.5 and signal["rsi"] < 55:
                signal["action"] = "buy"
                signal["reason"] = "Pullback near EMA200"
        else:
            if entry_price and signal["price"] >= entry_price * (1 + PARTIAL_TP_PCT):
                signal["action"] = "partial_sell"
                signal["reason"] = f"Partial TP +{PARTIAL_TP_PCT*100:.1f}%"
            elif last_buy_price and signal["price"] <= last_buy_price * (1 - REACCUMULATION_DROP_PCT):
                if signal["rsi"] < 50:
                    signal["action"] = "rebuy"
                    signal["reason"] = "Re-accumulation zone"

        return signal

    def calculate_buy_amount(self, price):
        free_usdt = self.exchange.get_balance()
        usable = max(0.0, free_usdt - MIN_CASH_BUFFER_USDT)
        amount = usable * MAX_POSITION_PCT
        return round(max(amount, 0.0), 2)

    def execute(self, signal):
        action = signal["action"]
        price = signal["price"]

        if action in ["buy", "rebuy"]:
            usdt_amount = self.calculate_buy_amount(price)
            if usdt_amount < 5.0:
                logger.info(f"Skip {action}: low balance ({usdt_amount:.2f} USDT)")
                return False

            order = self.exchange.create_market_buy(usdt_amount)
            if order:
                amount_base = usdt_amount / price
                update_position_state(self.state, action, amount_base, price)
                save_state(self.state)
                logger.info(f"{action.upper()} | {amount_base:.6f} LINK @ {price:.4f} | {signal['reason']}")
                return True

        elif action == "partial_sell":
            sell_amount = update_position_state(self.state, "partial_sell", 0, price)
            if sell_amount > 0.0001:
                order = self.exchange.create_market_sell(sell_amount)
                if order:
                    save_state(self.state)
                    logger.info(f"PARTIAL SELL | {sell_amount:.6f} LINK @ {price:.4f} | {signal['reason']}")
                    return True

        return False
